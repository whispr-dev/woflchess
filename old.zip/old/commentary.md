`quote from the austrian official turned whistle blower who wrote the a whole buncha code for spying on their own citizens:`
_“Once you’ve turned 30, either you decide to have a family and quit your job or you keep on working for the service and become strange”_ - Swiss programmer Ruben Unteregger developer of the Trojan 'Peskyspy'.

`His advice?`
_"Working in such a field makes people behave strangely. Do a job you can speak with your friends about while having a beer/coffee and getting opinions from a neutral side or at least one without professional interests._
_If you decide to make your passion to you profession, make sure you are your own boss. Otherwise its likely your passion gets spoiled because its influenced by other forces and it doesn’t take the direction YOU wish._
_Don’t make money to your main motivation when doing a job. It is distracting and leads you to unnecessary dependencies. Take curiosity as motivation instead and consider money as a nice side-effect."_
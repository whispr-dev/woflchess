use rand::Rng;
use std::fmt;

use crate::zobrist::{Zobrist, HASHER};

#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum Color { White, Black }

impl Color {
    #[inline] pub fn flip(self) -> Color { if self==Color::White { Color::Black } else { Color::White } }
}

#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum Piece { Pawn, Knight, Bishop, Rook, Queen, King }

#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub struct Square { pub f: u8, pub r: u8 } // file, rank 0..7

impl Square {
    #[inline] pub fn new(f:u8,r:u8)->Self { Self{f,r} }
    #[inline] pub fn idx(self)->usize { (self.r as usize)*8 + self.f as usize }
}

#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub struct Move {
    pub from: Square,
    pub to: Square,
    pub promo: Option<Piece>,
    pub is_enpassant: bool,
    pub is_castle: bool,
    pub capture: Option<Piece>,
}

impl Move {
    #[inline] pub fn quiet(from:Square,to:Square)->Self{ Self{from,to,promo:None,is_enpassant:false,is_castle:false,capture:None} }
    #[inline] pub fn capture(from:Square,to:Square,c:Piece)->Self{ Self{from,to,promo:None,is_enpassant:false,is_castle:false,capture:Some(c)} }
    #[inline] pub fn promo(from:Square,to:Square,p:Piece,capture:Option<Piece>)->Self{ Self{from,to,promo:Some(p),is_enpassant:false,is_castle:false,capture} }
    #[inline] pub fn castle(from:Square,to:Square)->Self{ Self{from,to,promo:None,is_enpassant:false,is_castle:true,capture:None} }
    pub fn to_uci(&self)->String{
        let mut s = String::new();
        s.push((b'a'+self.from.f) as char);
        s.push((b'1'+self.from.r) as char);
        s.push((b'a'+self.to.f) as char);
        s.push((b'1'+self.to.r) as char);
        if let Some(p)=self.promo {
            s.push(match p{Piece::Queen=>'q',Piece::Rook=>'r',Piece::Bishop=>'b',Piece::Knight=>'n',_=>'q'});
        }
        s
    }
}

#[derive(Clone)]
pub struct Board {
    // piece arrays per color per piece as bitboards
    bb: [[u64;6];2],
    stm: Color,
    castling: u8, // 1=K,2=Q,4=k,8=q
    ep: Option<u8>, // en passant file (0..7) if available, rank inferred by stm
    halfmove: u32,
    fullmove: u32,
    hash: u64,
    history: Vec<State>,
}

#[derive(Clone)]
struct State {
    hash: u64,
    castling: u8,
    ep: Option<u8>,
    halfmove: u32,
    captured: Option<(Color,Piece,Square)>,
    move_played: Move,
}

const KINGSIDE: [(u8,u8);2] = [(4,6),(60,62)];
const QUEENSIDE: [(u8,u8);2] = [(4,2),(60,58)];

impl Board {
    pub fn startpos() -> Self {
        Self::from_fen("rnbrqkbn/pppppppp/8/8/8/8/PPPPPPPP/RNBRQKBN w KQkq - 0 1".replace("rnbr","rnbq").replace("RNBR","RNBQ").as_str())
            .expect("hardcoded FEN")
    }

    pub fn from_fen(fen: &str) -> Result<Self,String> {
        let mut bb = [[0u64;6];2];
        let mut parts = fen.split_whitespace();
        let board = parts.next().ok_or("fen: board")?;
        let stm = parts.next().ok_or("fen: stm")?;
        let cast = parts.next().unwrap_or("-");
        let ep = parts.next().unwrap_or("-");
        let half = parts.next().unwrap_or("0").parse::<u32>().unwrap_or(0);
        let full = parts.next().unwrap_or("1").parse::<u32>().unwrap_or(1);

        let mut sq = 56; // a8
        for ch in board.chars() {
            match ch {
                '/' => { sq -= 16; }
                '1'..='8' => { sq += (ch as u8 - b'0') as i32 as i64 as i32 as usize; }
                _ => {
                    let (c,p) = char_to_piece(ch).ok_or("fen: piece")?;
                    bb[c as usize][p as usize] |= 1u64 << sq;
                    sq += 1;
                }
            }
        }
        let stm = if stm=="w" { Color::White } else { Color::Black };
        let mut castling = 0u8;
        if cast.contains('K') { castling |= 1; }
        if cast.contains('Q') { castling |= 2; }
        if cast.contains('k') { castling |= 4; }
        if cast.contains('q') { castling |= 8; }
        let ep = if ep != "-" {
            let bytes = ep.as_bytes();
            let file = (bytes[0]-b'a') as u8;
            Some(file)
        } else { None };

        let mut b = Board{ bb, stm, castling, ep, halfmove:half, fullmove:full, hash:0, history:Vec::new() };
        b.rehash();
        Ok(b)
    }

    #[inline] pub fn side_to_move(&self)->Color{ self.stm }

    #[inline] fn occup(&self)->u64 { self.color_occ(Color::White) | self.color_occ(Color::Black) }
    #[inline] fn color_occ(&self,c:Color)->u64 { self.bb[c as usize].iter().fold(0,|a,&x|a|x) }

    fn rehash(&mut self) {
        let mut h = 0u64;
        for c in 0..2 {
            for p in 0..6 {
                let mut bb = self.bb[c][p];
                while bb != 0 {
                    let sq = bb.trailing_zeros() as usize;
                    h ^= HASHER.piece[(c,p)][sq];
                    bb &= bb-1;
                }
            }
        }
        if self.stm==Color::Black { h ^= HASHER.black_to_move; }
        h ^= HASHER.castling[self.castling as usize];
        if let Some(f) = self.ep { h ^= HASHER.ep[f as usize]; }
        self.hash = h;
    }

    pub fn hash(&self)->u64 { self.hash }

    pub fn pretty(&self)->String{
        let mut s = String::new();
        for r in (0..8).rev() {
            s.push_str(&format!("{} ", r+1));
            for f in 0..8 {
                let ch = self.piece_on(Square::new(f as u8,r as u8)).map(piece_to_char).unwrap_or('.');
                s.push(ch);
                s.push(' ');
            }
            s.push('\n');
        }
        s.push_str("  a b c d e f g h\n");
        s
    }

    pub fn piece_on(&self, sq:Square) -> Option<(Color,Piece)> {
        let mask = 1u64 << sq.idx();
        for c in 0..2 {
            for p in 0..6 {
                if self.bb[c][p] & mask != 0 {
                    return Some((if c==0{Color::White}else{Color::Black}, idx_piece(p)));
                }
            }
        }
        None
    }

    pub fn legal_moves(&self)->Vec<Move> {
        let mut v = Vec::with_capacity(80);
        self.gen_moves(&mut v);
        v.into_iter().filter(|m| self.is_legal(*m)).collect()
    }

    pub fn is_in_check(&self, side:Color) -> bool {
        let king_sq = self.king_square(side);
        self.square_attacked(king_sq, side.flip())
    }

    fn king_square(&self, side:Color)->Square{
        let bb = self.bb[side as usize][Piece::King as usize];
        let idx = bb.trailing_zeros() as usize;
        Square::new((idx%8) as u8, (idx/8) as u8)
    }

    fn square_attacked(&self, sq:Square, by:Color)->bool{
        // pawns
        let mask = 1u64 << sq.idx();
        let their = &self.bb[by as usize];
        let pawn_att = if by==Color::White {
            ((their[Piece::Pawn as usize] & !FILE_H) << 9) | ((their[Piece::Pawn as usize] & !FILE_A) << 7)
        } else {
            ((their[Piece::Pawn as usize] & !FILE_A) >> 9) | ((their[Piece::Pawn as usize] & !FILE_H) >> 7)
        };
        if pawn_att & mask != 0 { return true; }
        // knights
        if knight_attacks(mask_index(mask)) & their[Piece::Knight as usize] != 0 { return true; }
        // bishops/queens
        if bishop_attacks(self.occup(), sq.idx() as u8) & (their[Piece::Bishop as usize] | their[Piece::Queen as usize]) != 0 { return true; }
        // rooks/queens
        if rook_attacks(self.occup(), sq.idx() as u8) & (their[Piece::Rook as usize] | their[Piece::Queen as usize]) != 0 { return true; }
        // king
        if king_attacks(mask_index(mask)) & their[Piece::King as usize] != 0 { return true; }
        false
    }

    fn is_legal(&self, m:Move)->bool{
        let mut b = self.clone();
        b.make_move(m);
        !b.is_in_check(self.stm)
    }

    pub fn make_move(&mut self, m:Move){
        let side = self.stm;
        let mut captured: Option<(Color,Piece,Square)> = None;

        // save state
        self.history.push(State{
            hash:self.hash, castling:self.castling, ep:self.ep, halfmove:self.halfmove, captured:None, move_played:m
        });

        let from_idx = m.from.idx();
        let to_idx = m.to.idx();

        // find piece moving
        let (pc_side, pc) = self.piece_on(m.from).expect("move from empty");
        debug_assert_eq!(pc_side, side);

        // update halfmove/fullmove
        self.halfmove += 1;
        if side==Color::Black { self.fullmove += 1; }

        // clear EP
        self.ep = None;

        // remove piece from from
        self.bb[side as usize][pc as usize] &= !(1u64<<from_idx);

        // handle captures (including en passant)
        let mut capture_piece = None;
        if let Some(cap) = m.capture {
            capture_piece = Some(cap);
            let cap_sq = if m.is_enpassant {
                // pawn captures en passant
                if side==Color::White {
                    Square::new(m.to.f, m.to.r-1)
                } else {
                    Square::new(m.to.f, m.to.r+1)
                }
            } else { m.to };
            self.remove_piece(cap_sq);
            captured = Some((side.flip(), cap, cap_sq));
            self.halfmove = 0;
        }

        // promotions
        if pc==Piece::Pawn && m.promo.is_some() {
            let p = m.promo.unwrap();
            self.bb[side as usize][p as usize] |= 1u64<<to_idx;
            self.halfmove = 0;
        } else {
            // normal move
            self.bb[side as usize][pc as usize] |= 1u64<<to_idx;
            if pc==Piece::Pawn { self.halfmove = 0; }
        }

        // castling rights & rook moves
        self.update_castling_rights(pc, side, m);

        // set en passant square on double pawn push
        if pc==Piece::Pawn && (m.from.r as i8 - m.to.r as i8).abs()==2 {
            self.ep = Some(m.from.f);
        }

        // rook relocation on castles
        if m.is_castle {
            if m.to.f == 6 { // king side
                let rf = 7; let tf = 5;
                self.move_rook(side, rf, m.from.r, tf, m.from.r);
            } else { // queen side
                let rf = 0; let tf = 3;
                self.move_rook(side, rf, m.from.r, tf, m.from.r);
            }
        }

        // side change
        self.stm = self.stm.flip();

        // recompute hash
        self.rehash();

        // record captured into state
        if let Some(st) = self.history.last_mut() {
            st.captured = captured;
        }
    }

    pub fn unmake_last(&mut self)->bool{
        let st = match self.history.pop() { Some(s)=>s, None=>return false };
        self.hash = st.hash;
        self.castling = st.castling;
        self.ep = st.ep;
        self.halfmove = st.halfmove;

        // revert side
        self.stm = self.stm.flip();

        // reverse move
        let m = st.move_played;
        let (side, from, to) = (self.stm, m.from, m.to);

        // identify piece that moved (look at current board at 'to')
        // remove whatever is at 'to'
        let moved = self.remove_piece(to).expect("to must have piece after forward");
        let mut moving_piece = moved.1;

        // undo castle rook shuffle
        if m.is_castle {
            if to.f == 6 { // kingside
                self.move_rook(side, 5, from.r, 7, from.r);
            } else {
                self.move_rook(side, 3, from.r, 0, from.r);
            }
        }

        // handle promotions
        if let Some(p) = m.promo {
            // remove promoted piece and restore pawn on from
            debug_assert_eq!(moving_piece, p);
            self.bb[side as usize][p as usize] &= !(1u64<<to.idx());
            moving_piece = Piece::Pawn;
        }

        // restore mover to from
        self.bb[side as usize][moving_piece as usize] |= 1u64<<from.idx();

        // restore capture
        if let Some((cside, cpiece, csq)) = st.captured {
            self.bb[cside as usize][cpiece as usize] |= 1u64<<csq.idx();
        }

        true
    }

    fn remove_piece(&mut self, sq:Square) -> Option<(Color,Piece)> {
        let mask = 1u64<<sq.idx();
        for c in 0..2 {
            for p in 0..6 {
                if self.bb[c][p] & mask != 0 {
                    self.bb[c][p] &= !mask;
                    return Some((if c==0{Color::White}else{Color::Black}, idx_piece(p)));
                }
            }
        }
        None
    }

    fn move_rook(&mut self, side:Color, rf:u8, rr:u8, tf:u8, tr:u8) {
        let from = Square::new(rf, rr);
        let to = Square::new(tf, tr);
        let _ = self.remove_piece(from);
        self.bb[side as usize][Piece::Rook as usize] |= 1u64 << to.idx();
    }

    fn update_castling_rights(&mut self, pc:Piece, side:Color, m:Move) {
        // moving king removes both rights
        match (side, pc) {
            (Color::White, Piece::King) => { self.castling &= !(1|2); }
            (Color::Black, Piece::King) => { self.castling &= !(4|8); }
            _ => {}
        }
        // if rook moved from its original squares, drop related right
        if side==Color::White {
            if pc==Piece::Rook && m.from.r==0 && m.from.f==0 { self.castling &= !2; }
            if pc==Piece::Rook && m.from.r==0 && m.from.f==7 { self.castling &= !1; }
        } else {
            if pc==Piece::Rook && m.from.r==7 && m.from.f==0 { self.castling &= !8; }
            if pc==Piece::Rook && m.from.r==7 && m.from.f==7 { self.castling &= !4; }
        }
        // if rook captured off original squares
        if let Some(Piece::Rook) = m.capture {
            if m.to.r==0 && m.to.f==0 { self.castling &= !2; }
            if m.to.r==0 && m.to.f==7 { self.castling &= !1; }
            if m.to.r==7 && m.to.f==0 { self.castling &= !8; }
            if m.to.r==7 && m.to.f==7 { self.castling &= !4; }
        }
    }

    pub fn gen_moves(&self, out:&mut Vec<Move>) {
        gen_all_moves(self, out);
    }

    pub fn is_game_over(&self)->bool{
        if !self.legal_moves().is_empty() { return false; }
        // stalemate vs checkmate decided by side in check
        true
    }

    pub fn result_string(&self)->String{
        if !self.is_game_over() { return String::new(); }
        if self.is_in_check(self.stm) {
            format!("Checkmate. {:?} wins.", self.stm.flip())
        } else {
            "Stalemate".to_string()
        }
    }

    pub fn evaluate(&self)->i32 {
        // tapered eval: material + PST blend
        let (mg, eg) = eval_material_pst(self);
        // simple endgame phase from material
        let phase = game_phase(self);
        ((mg*(256-phase) + eg*phase) / 256) as i32 * if self.stm==Color::White {1} else {-1}
    }

    pub fn perft(&mut self, depth:u32)->u64{
        if depth==0 { return 1; }
        let moves = self.legal_moves();
        let mut nodes = 0;
        for m in moves {
            self.make_move(m);
            nodes += self.perft(depth-1);
            self.unmake_last();
        }
        nodes
    }

    pub fn side_material(&self, side:Color)->i32 {
        let idx = side as usize;
        let mut v = 0;
        v += popcount(self.bb[idx][Piece::Pawn as usize])   * 100;
        v += popcount(self.bb[idx][Piece::Knight as usize]) * 320;
        v += popcount(self.bb[idx][Piece::Bishop as usize]) * 330;
        v += popcount(self.bb[idx][Piece::Rook as usize])   * 500;
        v += popcount(self.bb[idx][Piece::Queen as usize])  * 900;
        v
    }
}

// ======== MOVE GENERATION (bitboard helpers) ========

const FILE_A:u64 = 0x0101010101010101;
const FILE_H:u64 = 0x8080808080808080;

#[inline] fn mask_index(mask:u64)->u8 { mask.trailing_zeros() as u8 }
#[inline] fn popcount(x:u64)->i32 { x.count_ones() as i32 }

fn char_to_piece(c:char)->Option<(usize,Piece)>{
    use Piece::*;
    match c {
        'P'=>Some((0,Pawn)),'N'=>Some((0,Knight)),'B'=>Some((0,Bishop)),'R'=>Some((0,Rook)),'Q'=>Some((0,Queen)),'K'=>Some((0,King)),
        'p'=>Some((1,Pawn)),'n'=>Some((1,Knight)),'b'=>Some((1,Bishop)),'r'=>Some((1,Rook)),'q'=>Some((1,Queen)),'k'=>Some((1,King)),
        _=>None
    }
}
fn piece_to_char(p:(Color,Piece))->char{
    use Piece::*;
    let (c,pc) = p;
    let ch = match pc { Pawn=>'p',Knight=>'n',Bishop=>'b',Rook=>'r',Queen=>'q',King=>'k' };
    if c==Color::White { ch.to_ascii_uppercase() } else { ch }
}

// sliding attacks via naive rays (fast enough for our depth)
fn ray(occ:u64, sq:u8, del:i8)->u64 {
    let mut r = 0u64;
    let mut s = sq as i8;
    loop {
        let f = (s%8) as i8;
        s += del;
        if s<0 || s>=64 { break; }
        let nf = (s%8) as i8;
        if (nf-f).abs()>1 { break; } // wrapped file
        r |= 1u64<<(s as u8);
        if (occ & (1u64<<(s as u8)))!=0 { break; }
    }
    r
}
fn bishop_attacks(occ:u64, sq:u8)->u64 {
    ray(occ,sq,9) | ray(occ,sq,7) | ray(occ,sq,-7) | ray(occ,sq,-9)
}
fn rook_attacks(occ:u64, sq:u8)->u64 {
    ray(occ,sq,8) | ray(occ,sq,-8) | ray(occ,sq,1) | ray(occ,sq,-1)
}
fn knight_attacks(sq:u8)->u64 {
    const O: [(i8,i8);8] = [(1,2),(2,1),(2,-1),(1,-2),(-1,-2),(-2,-1),(-2,1),(-1,2)];
    let f = (sq%8) as i8; let r = (sq/8) as i8;
    let mut m=0;
    for (df,dr) in O {
        let nf=f+df; let nr=r+dr;
        if (0..8).contains(&nf) && (0..8).contains(&nr) {
            m |= 1u64<<((nr*8+nf) as u8);
        }
    }
    m
}
fn king_attacks(sq:u8)->u64{
    let f=(sq%8) as i8; let r=(sq/8) as i8;
    let mut m=0;
    for df in -1..=1 {
        for dr in -1..=1 {
            if df==0 && dr==0 { continue; }
            let nf=f+df; let nr=r+dr;
            if (0..8).contains(&nf) && (0..8).contains(&nr) {
                m |= 1u64<<((nr*8+nf) as u8);
            }
        }
    }
    m
}

fn gen_all_moves(b:&Board, out:&mut Vec<Move>) {
    out.clear();
    let side = b.stm;
    let us = side as usize;
    let them = side.flip() as usize;
    let occ = b.occup();
    let ours = b.color_occ(side);
    let theirs = b.color_occ(side.flip());

    // PAWNS
    let pawns = b.bb[us][Piece::Pawn as usize];
    if side==Color::White {
        let one = (pawns<<8) & !occ;
        let two = ((one & (0x000000000000FF00<<8))<<8) & !occ;
        // quiet pushes
        let mut m = one;
        while m!=0 {
            let to = m.trailing_zeros() as u8;
            let from = to-8;
            push_pawn_move(b,out,from,to,None);
            m&=m-1;
        }
        let mut m2 = two;
        while m2!=0 {
            let to = m2.trailing_zeros() as u8;
            let from = to-16;
            out.push(Move::quiet(Square::new((from%8) as u8,(from/8) as u8), Square::new((to%8) as u8,(to/8) as u8)));
            m2&=m2-1;
        }
        // captures
        let left = (pawns & !FILE_A) << 7 & theirs;
        let right= (pawns & !FILE_H) << 9 & theirs;
        push_pawn_caps(b,out,left,7);
        push_pawn_caps(b,out,right,9);
        // en passant
        if let Some(file)=b.ep {
            let target_rank = 5u8;
            let ep_sq = Square::new(file, target_rank);
            let ep_mask = 1u64<<ep_sq.idx();
            // attackers
            let left = (pawns & !FILE_H) << 9;
            let right= (pawns & !FILE_A) << 7;
            if left & ep_mask != 0 {
                let from = ep_sq.idx() as i32 - 9;
                out.push(Move{from:idx_sq(from as u8), to:ep_sq, promo:None, is_enpassant:true, is_castle:false, capture:Some(Piece::Pawn)});
            }
            if right & ep_mask != 0 {
                let from = ep_sq.idx() as i32 - 7;
                out.push(Move{from:idx_sq(from as u8), to:ep_sq, promo:None, is_enpassant:true, is_castle:false, capture:Some(Piece::Pawn)});
            }
        }
    } else {
        let one = (pawns>>8) & !occ;
        let two = ((one & (0x00FF000000000000>>8))>>8) & !occ;
        let mut m = one;
        while m!=0 {
            let to = m.trailing_zeros() as u8;
            let from = to+8;
            push_pawn_move(b,out,from,to,None);
            m&=m-1;
        }
        let mut m2 = two;
        while m2!=0 {
            let to = m2.trailing_zeros() as u8;
            let from = to+16;
            out.push(Move::quiet(idx_sq(from), idx_sq(to)));
            m2&=m2-1;
        }
        // captures
        let left = (pawns & !FILE_A) >> 9 & theirs;
        let right= (pawns & !FILE_H) >> 7 & theirs;
        push_pawn_caps(b,out,left,-9);
        push_pawn_caps(b,out,right,-7);
        // en passant
        if let Some(file)=b.ep {
            let ep_sq = Square::new(file, 2);
            let ep_mask = 1u64<<ep_sq.idx();
            let left = (pawns & !FILE_A) >> 9;
            let right= (pawns & !FILE_H) >> 7;
            if left & ep_mask != 0 {
                let from = ep_sq.idx() as i32 + 9;
                out.push(Move{from:idx_sq(from as u8), to:ep_sq, promo:None, is_enpassant:true, is_castle:false, capture:Some(Piece::Pawn)});
            }
            if right & ep_mask != 0 {
                let from = ep_sq.idx() as i32 + 7;
                out.push(Move{from:idx_sq(from as u8), to:ep_sq, promo:None, is_enpassant:true, is_castle:false, capture:Some(Piece::Pawn)});
            }
        }
    }

    // KNIGHTS
    let mut n = b.bb[us][Piece::Knight as usize];
    while n!=0 {
        let sq = n.trailing_zeros() as u8;
        let att = knight_attacks(sq) & !ours;
        push_attacks(b,out,sq,att);
        n&=n-1;
    }

    // BISHOPS
    let mut bb = b.bb[us][Piece::Bishop as usize];
    while bb!=0 {
        let sq = bb.trailing_zeros() as u8;
        let att = bishop_attacks(occ, sq) & !ours;
        push_attacks(b,out,sq,att);
        bb&=bb-1;
    }

    // ROOKS
    let mut rr = b.bb[us][Piece::Rook as usize];
    while rr!=0 {
        let sq = rr.trailing_zeros() as u8;
        let att = rook_attacks(occ, sq) & !ours;
        push_attacks(b,out,sq,att);
        rr&=rr-1;
    }

    // QUEENS
    let mut qq = b.bb[us][Piece::Queen as usize];
    while qq!=0 {
        let sq = qq.trailing_zeros() as u8;
        let att = (rook_attacks(occ,sq)|bishop_attacks(occ,sq)) & !ours;
        push_attacks(b,out,sq,att);
        qq&=qq-1;
    }

    // KING + castling
    let ksq = b.bb[us][Piece::King as usize].trailing_zeros() as u8;
    let katt = king_attacks(ksq) & !ours;
    push_attacks(b,out,ksq,katt);

    // castling checks
    let in_check = b.is_in_check(b.stm);
    if !in_check {
        // K-side
        if (us==0 && (b.castling&1)!=0) || (us==1 && (b.castling&4)!=0) {
            let between = if us==0 { (1u64<<5)|(1u64<<6) } else { (1u64<<61)|(1u64<<62) };
            if between & occ == 0 {
                let path_ok = !b.square_attacked(idx_sq(if us==0{5}else{61}), b.stm.flip())
                            && !b.square_attacked(idx_sq(if us==0{6}else{62}), b.stm.flip());
                if path_ok {
                    out.push(Move::castle(idx_sq(ksq), idx_sq(if us==0{6}else{62})));
                }
            }
        }
        // Q-side
        if (us==0 && (b.castling&2)!=0) || (us==1 && (b.castling&8)!=0) {
            let between = if us==0 { (1u64<<1)|(1u64<<2)|(1u64<<3) } else { (1u64<<57)|(1u64<<58)|(1u64<<59) };
            if between & occ == 0 {
                let path_ok = !b.square_attacked(idx_sq(if us==0{2}else{58}), b.stm.flip())
                            && !b.square_attacked(idx_sq(if us==0{3}else{59}), b.stm.flip());
                if path_ok {
                    out.push(Move::castle(idx_sq(ksq), idx_sq(if us==0{2}else{58})));
                }
            }
        }
    }
}

fn idx_sq(idx:u8)->Square{ Square::new((idx%8) as u8,(idx/8) as u8) }

fn push_attacks(b:&Board, out:&mut Vec<Move>, from:u8, targets:u64){
    let from_sq = idx_sq(from);
    let mut t = targets;
    while t!=0 {
        let to = t.trailing_zeros() as u8;
        let to_sq = idx_sq(to);
        let cap = b.piece_on(to_sq).map(|p|p.1);
        out.push(if let Some(c)=cap { Move::capture(from_sq,to_sq,c) } else { Move::quiet(from_sq,to_sq) });
        t &= t-1;
    }
}

fn push_pawn_move(b:&Board, out:&mut Vec<Move>, from:u8, to:u8, cap:Option<Piece>) {
    let from_sq = idx_sq(from);
    let to_sq = idx_sq(to);
    let rank = to_sq.r;
    if rank==0 || rank==7 {
        for p in [Piece::Queen, Piece::Rook, Piece::Bishop, Piece::Knight] {
            out.push(Move::promo(from_sq,to_sq,p,cap));
        }
    } else {
        out.push(if let Some(c)=cap { Move::capture(from_sq,to_sq,c) } else { Move::quiet(from_sq,to_sq) });
    }
}
fn push_pawn_caps(b:&Board, out:&mut Vec<Move>, mut mask:u64, delta:i32){
    while mask!=0 {
        let to = mask.trailing_zeros() as u8;
        let from = (to as i32 - delta) as u8;
        let cap = b.piece_on(idx_sq(to)).map(|p|p.1);
        push_pawn_move(b,out,from,to,cap);
        mask&=mask-1;
    }
}

// ======== evaluation ========

fn eval_material_pst(b:&Board)->(i32,i32){
    // material + simple PSTs (MG/EG)
    let mgpst = pst_mg();
    let egpst = pst_eg();

    let mut mg = 0i32;
    let mut eg = 0i32;
    for side in [Color::White, Color::Black] {
        let s = if side==Color::White {1} else {-1};
        for (p, val) in [
            (Piece::Pawn,100),
            (Piece::Knight,320),
            (Piece::Bishop,330),
            (Piece::Rook,500),
            (Piece::Queen,900),
            (Piece::King,0),
        ] {
            let mut bbp = b.bb[side as usize][p as usize];
            while bbp!=0 {
                let sq = bbp.trailing_zeros() as usize;
                mg += s * (val + mgpst[p as usize][map_sq(side,sq)]);
                eg += s * (val + egpst[p as usize][map_sq(side,sq)]);
                bbp&=bbp-1;
            }
        }
    }
    (mg,eg)
}

fn game_phase(b:&Board)->i32{
    // simplistic phase metric based on non-pawn material
    let w = b.side_material(Color::White);
    let bl = b.side_material(Color::Black);
    let total = (w+bl).max(1);
    let pawn = (popcount(b.bb[0][Piece::Pawn as usize]) + popcount(b.bb[1][Piece::Pawn as usize]))*100;
    let phase = ((total - pawn) * 256 / 620).clamp(0,256);
    phase
}

fn map_sq(side:Color, sq:usize)->usize{
    if side==Color::White { sq } else { ((7-(sq/8))*8 + (sq%8)) }
}

fn pst_mg()->[[i32;64];6] {
    // quick PSTs (placeholder but deterministic/complete)
    const Z:[i32;64] = [0;64];
    [Z;6]
}
fn pst_eg()->[[i32;64];6] {
    const Z:[i32;64] = [0;64];
    [Z;6]
}

use rand::Rng;

use crate::board::{Color, Piece};

pub struct Zobrist {
    pub piece: [ [u64;64]; 12 ], // [color*6 + piece][sq]
    pub black_to_move: u64,
    pub castling: [u64;16],
    pub ep: [u64;8],
}

lazy_static::lazy_static! {
    pub static ref HASHER: Zobrist = {
        let mut rng = rand::thread_rng();
        let mut piece = [[0u64;64];12];
        for i in 0..12 { for s in 0..64 { piece[i][s] = rng.gen::<u64>(); } }
        let mut castling = [0u64;16];
        for i in 0..16 { castling[i] = rng.gen::<u64>(); }
        let mut ep = [0u64;8];
        for i in 0..8 { ep[i] = rng.gen::<u64>(); }

        Zobrist {
            piece, black_to_move: rng.gen::<u64>(), castling, ep
        }
    };
}

impl Zobrist {
    #[inline]
    pub fn index(color: Color, p: Piece) -> usize {
        (if color==Color::White {0} else {6}) + p as usize
    }
}

// convenience so board.rs can use HASHER.piece[(c,p)][sq]
pub trait ZWrap {
    fn piece(&self, c:usize, p:usize, sq:usize) -> u64;
}

impl ZWrap for Zobrist {
    fn piece(&self, _c:usize, _p:usize, _sq:usize) -> u64 {
        // not used directly; board uses piece[(c,p)][sq] via custom indexing
        0
    }
}

// little trick to allow indexing style HASHER.piece[(c,p)][sq]
impl std::ops::Index<(usize,usize)> for [[u64;64];12] {
    type Output = [u64;64];
    fn index(&self, index:(usize,usize)) -> &Self::Output {
        &self[index.0*6 + index.1]
    }
}

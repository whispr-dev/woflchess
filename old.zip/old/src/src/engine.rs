use ahash::AHashMap;
use chess::{Board, ChessMove, MoveGen, Color, Piece, BoardStatus, Square};

#[derive(Copy, Clone, Debug)]
pub struct SearchLimits { pub depth: u32 }

#[derive(Copy, Clone, Debug)]
enum NodeType { Exact, Lower, Upper }

#[derive(Copy, Clone, Debug)]
struct TTEntry { depth: u8, score: i32, mv: Option<ChessMove>, node: NodeType }

pub struct Engine {
    tt: AHashMap<u64, TTEntry>,
    default_depth: u32,
}

impl Engine {
    pub fn new() -> Self {
        Self { tt: AHashMap::with_capacity(1<<20), default_depth: 5 }
    }
    pub fn default_depth(&self)->u32 { self.default_depth }
    pub fn set_default_depth(&mut self, d:u32) { self.default_depth = d.clamp(1, 8); }

    pub fn search(&mut self, board:&Board, limits:SearchLimits) -> (i32, ChessMove) {
        let mut best = None;
        let mut score = 0;
        for d in 1..=limits.depth {
            let (sc, mv) = self.negamax(*board, d as i32, -30_000, 30_000);
            if let Some(mv) = mv { best = Some(mv); score = sc; }
        }
        (score, best.unwrap())
    }

    fn negamax(&mut self, board:Board, depth:i32, mut alpha:i32, beta:i32) -> (i32, Option<ChessMove>) {
        if depth <= 0 {
            return (self.qsearch(board, alpha, beta), None);
        }
        if matches!(board.status(), BoardStatus::Stalemate) { return (0, None); }
        if matches!(board.status(), BoardStatus::Checkmate) { return (-30_000 + (5-depth), None); }

        let key = board.get_hash();
        if let Some(tt) = self.tt.get(&key) {
            if tt.depth as i32 >= depth {
                match tt.node {
                    NodeType::Exact => return (tt.score, tt.mv),
                    NodeType::Lower => alpha = alpha.max(tt.score),
                    NodeType::Upper => {},
                }
                if alpha >= beta { return (tt.score, tt.mv); }
            }
        }

        let mut gen = MoveGen::new_legal(&board);
        let mut moves: Vec<ChessMove> = gen.collect();

        // captures first
        moves.sort_unstable_by_key(|m| {
            let cap = board.piece_on(m.get_dest()).map(|p| piece_value(p as usize)).unwrap_or(0);
            -cap
        });

        let mut best_mv = None;
        let mut value = -30_000;

        for m in moves {
            let nb = board.make_move_new(m);
            let (sc, _) = self.negamax(nb, depth-1, -beta, -alpha);
            let sc = -sc;
            if sc > value { value = sc; best_mv = Some(m); }
            if value > alpha { alpha = value; }
            if alpha >= beta { break; }
        }

        let node_flag = if value <= alpha { NodeType::Upper }
                        else if value >= beta { NodeType::Lower }
                        else { NodeType::Exact };
        self.tt.insert(key, TTEntry { depth: depth as u8, score: value, mv: best_mv, node: node_flag });
        (value, best_mv)
    }

    fn qsearch(&mut self, board:Board, mut alpha:i32, beta:i32) -> i32 {
        let stand_pat = evaluate(&board);
        if stand_pat >= beta { return beta; }
        if alpha < stand_pat { alpha = stand_pat; }

        let gen = MoveGen::new_legal(&board);
        for m in gen {
            if board.piece_on(m.get_dest()).is_none() { continue; } // only captures
            let nb = board.make_move_new(m);
            let sc = -self.qsearch(nb, -beta, -alpha);
            if sc >= beta { return beta; }
            if sc > alpha { alpha = sc; }
        }
        alpha
    }
}

fn piece_value(idx: usize) -> i32 {
    match idx {
        1 => 100, // Pawn
        2 => 320, // Knight
        3 => 330, // Bishop
        4 => 500, // Rook
        5 => 900, // Queen
        6 => 0,   // King
        _ => 0
    }
}

fn evaluate(board:&Board) -> i32 {
    let mut score = 0;

    for sq in chess::ALL_SQUARES {
        if let Some(p) = board.piece_on(sq) {
            let v = piece_value(p as usize);
            score += match board.color_on(sq).unwrap() {
                Color::White => v,
                Color::Black => -v,
            };
        }
    }

    // Tempo
    if board.side_to_move() == Color::White { score } else { -score }
}

// -- Parsing UCI to ChessMove by matching legal list --
pub fn parse_uci(board:&Board, s:&str) -> Option<ChessMove> {
    // supports e2e4, e7e8q etc.
    if s.len() < 4 { return None; }
    let bytes = s.as_bytes();
    let file = |b:u8| -> Option<u8> {
        if (b'a'..=b'h').contains(&b) { Some(b - b'a') } else { None }
    };
    let rank = |b:u8| -> Option<u8> {
        if (b'1'..=b'8').contains(&b) { Some(b - b'1') } else { None }
    };
    let f1 = file(bytes[0])?;
    let r1 = rank(bytes[1])?;
    let f2 = file(bytes[2])?;
    let r2 = rank(bytes[3])?;
    let src = Square::make_square(chess::Rank::from_index(r1 as usize), chess::File::from_index(f1 as usize));
    let dst = Square::make_square(chess::Rank::from_index(r2 as usize), chess::File::from_index(f2 as usize));
    let promo = if s.len() == 5 {
        match bytes[4] as char {
            'q'|'Q' => Some(Piece::Queen),
            'r'|'R' => Some(Piece::Rook),
            'b'|'B' => Some(Piece::Bishop),
            'n'|'N' => Some(Piece::Knight),
            _ => None,
        }
    } else { None };

    let gen = MoveGen::new_legal(board);
    for m in gen {
        if m.get_source()==src && m.get_dest()==dst {
            if promo.is_some() == m.get_promotion().is_some() {
                if promo.is_none() || promo.unwrap()==m.get_promotion().unwrap() { return Some(m); }
            }
        }
    }
    None
}

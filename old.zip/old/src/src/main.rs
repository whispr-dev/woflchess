use std::io::{self, Write};
use chess::{Board, BoardStatus, Color};

mod engine;
use engine::{Engine, SearchLimits, parse_uci};

fn main() {
    println!("woflchess: local-only AI chess. Commands: 'quit', 'depth N', 'fen <FEN>' or UCI move like e2e4.");
    let mut board = Board::default();
    let mut engine = Engine::new();

    loop {
        println!("{}", board);
        if matches!(board.status(), BoardStatus::Checkmate) {
            println!("Checkmate. {} wins.", if board.side_to_move()==Color::White {"Black"} else {"White"});
            break;
        }
        if matches!(board.status(), BoardStatus::Stalemate) {
            println!("Draw by stalemate.");
            break;
        }

        print!("Your move> ");
        io::stdout().flush().ok();
        let mut line = String::new();
        if io::stdin().read_line(&mut line).is_err() { break; }
        let line = line.trim();

        if line.eq_ignore_ascii_case("quit") { break; }
        if let Some(rest) = line.strip_prefix("depth ") {
            if let Ok(d)=rest.parse::<u32>() { engine.set_default_depth(d); println!("Depth set to {}", d); }
            continue;
        }
        if let Some(rest) = line.strip_prefix("fen ") {
            if let Ok(b) = Board::from_fen(rest) {
                board = b;
                continue;
            } else {
                println!("Bad FEN.");
                continue;
            }
        }

        let Some(user_mv) = parse_uci(&board, line) else {
            println!("Illegal/unknown move. Use UCI like e2e4.");
            continue;
        };
        board = board.make_move_new(user_mv);

        print!("Thinking (depth {})...", engine.default_depth());
        io::stdout().flush().ok();
        let (_eval, best) = engine.search(&board, SearchLimits { depth: engine.default_depth() });
        println!("\nEngine plays {}", best);
        board = board.make_move_new(best);
    }
}

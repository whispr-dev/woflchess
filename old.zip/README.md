# woflchess
 chess coded in rust


202502160346 Sun

a continuation of my learning to code in Rust in the form of a chess game. intention long run is to have an ai computer opponent the uses ml to improve and hopefully innovate.

v.0.1.0 is absolute raw basic chess, bare minimum board gfx and a few slightly more verbose err msgs when attempting invalid moves:

  abcdefgh
 ----------
1 rnbqknbr 1
2 pppppppp 2
3 ........ 3
4 ........ 4
5 ........ 5
6 ........ 6
7 PPPPPPPP 7
8 RNBKQBNR 8
 ----------
  abcdefgh

classy gfx eh!
oh, it also supports `quit` to exit game at turn prompt.
